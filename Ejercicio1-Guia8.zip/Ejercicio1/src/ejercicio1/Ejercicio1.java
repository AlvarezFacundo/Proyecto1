/*
Diseñar un programa que lea y guarde razas de perros en un ArrayList de tipo String. El
programa pedirá una raza de perro en un bucle, el mismo se guardará en la lista y
después se le preguntará al usuario si quiere guardar otro perro o si quiere salir. Si decide
salir, se mostrará todos los perros guardados en el ArrayList.
 */
package ejercicio1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 *  
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in).useDelimiter("\n");

        ArrayList<String> listaPerros = new ArrayList();

        String salir;

        do {

            System.out.println("Ingrese una raza de perros: ");
            String perro = leer.next();

            listaPerros.add(perro);

            System.out.println("Desea continuar? (s para continuar, cualquier tecla para salir).");
            salir = leer.next();

        } while (salir.equalsIgnoreCase("S"));
        
        System.out.println("Las razas ingresadas son: ");
        System.out.println(listaPerros.toString());

    }

}
