/*
 *  Se requiere un programa que lea y guarde países, y para evitar que se ingresen repetidos
usaremos un conjunto. El programa pedirá un país en un bucle, se guardará el país en el
conjunto y después se le preguntará al usuario si quiere guardar otro país o si quiere salir,
si decide salir, se mostrará todos los países guardados en el conjunto. (Recordemos hacer
los servicios en la clase correspondiente)
Después deberemos mostrar el conjunto ordenado alfabéticamente: para esto recordar
cómo se ordena un conjunto.
Por último, al usuario se le pedirá un país y se recorrerá el conjunto con un Iterator, se
buscará el país en el conjunto y si está en el conjunto se eliminará el país que ingresó el
usuario y se mostrará el conjunto. Si el país no se encuentra en el conjunto se le informará
al usuario.
 */
package servicio;

import entidades.Pais;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class servicioPais {

    Scanner leer;

    public servicioPais() {
        leer = new Scanner(System.in).useDelimiter("\n");
    }

    public Pais crearPais() {
        Pais p1 = new Pais();
        HashSet <String> conjuntoPaises = new HashSet<>();
        p1.setPaises(conjuntoPaises);
        return p1;
    }

    public void sumarPais(Pais p1) {

        String validar;
        do {
            System.out.println("ingrese el nombre del pais a agregar");
            String Pai = leer.next();
            p1.getPaises().add(Pai);
            System.out.println("desea agregar otro pais? (S/N)");
            validar = leer.next();
        } while (validar.equalsIgnoreCase("s"));

    }

    public void mostrarSet(Pais p1) {

        for (String pa : p1.getPaises()) {
            System.out.println(pa);
        }
    }

    public void mostrarOrdenado(Pais p1) {
        System.out.println("----------------------------------------------------");
        TreeSet<String> orde = new TreeSet<>(p1.getPaises());
        for (String pa : orde) {
            System.out.println(pa);
        }
    }

    public void eliminarPais(Pais p1) {

        System.out.println("ingrese el nombre del pais a eliminar");
        String pai = leer.next();
        boolean val = false;
        Iterator<String> it = p1.getPaises().iterator();
        while (it.hasNext()) {

            if (it.next().equalsIgnoreCase(pai)) {
                it.remove();
                val = true;
            }

        }
        if (val == false) {
            System.out.println("no se encuentra el pais buscado");
        }
        if (val) {
            mostrarOrdenado(p1);
        }
    }
}
