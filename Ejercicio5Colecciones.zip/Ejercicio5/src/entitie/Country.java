/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entitie;

import java.util.Comparator;
import java.util.Objects;

/**
 *
 * @author Juan Cruz
 */
public class Country {
    
    private String countryName;

    public Country() {
    }

    public Country(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    @Override
    public String toString() {
        return countryName;
    }
    
    public static Comparator<Country> compareCountry = new Comparator<Country>() {
        @Override
        public int compare(Country c1, Country c2) {
            return c1.getCountryName().compareTo(c2.getCountryName());
        }
    };
    
}
