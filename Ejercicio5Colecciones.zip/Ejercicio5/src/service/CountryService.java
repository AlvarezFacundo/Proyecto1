/*
 * Se requiere un programa que lea y guarde países, y para evitar que se ingresen repetidos
usaremos un conjunto. El programa pedirá un país en un bucle, se guardará el país en el
conjunto y después se le preguntará al usuario si quiere guardar otro país o si quiere salir,
si decide salir, se mostrará todos los países guardados en el conjunto. (Recordemos hacer
los servicios en la clase correspondiente)
Después deberemos mostrar el conjunto ordenado alfabéticamente: para esto recordar
cómo se ordena un conjunto.
Por último, al usuario se le pedirá un país y se recorrerá el conjunto con un Iterator, se
buscará el país en el conjunto y si está en el conjunto se eliminará el país que ingresó el
usuario y se mostrará el conjunto. Si el país no se encuentra en el conjunto se le informará
al usuario.
 */
package service;

import entitie.Country;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author Juan Cruz
 */
public class CountryService {
    
    Scanner leer;

    public CountryService() {
        
        leer = new Scanner(System.in).useDelimiter("\n");
        
    }
    
    public Country createCountry(){
        
        Country countryEx = new Country();
        
        System.out.println("Ingrese el país que desea agregar: ");
        countryEx.setCountryName(leer.next());
        
        return countryEx;
    }
    
    public HashSet<Country> createCountrySet (){
        
        boolean exit = true;
        HashSet<Country> countrySet = new HashSet<>();
        
        while (exit) {            
            
            Country newCountry = createCountry();
            
            countrySet.add(newCountry);
            
            System.out.println("¿Desea contrinuar? (s para continuar, cualquier tecla para salir) ");
            
            String exitCheck = leer.next();
            
            if ( !exitCheck.equalsIgnoreCase("s") ){
                
                exit = false;
                
            }
            
        }
        
        return countrySet;
        
    }
    
    public void showSortedCountrySet( HashSet<Country> countrySet ){
        
        ArrayList<Country> countryList = new ArrayList<>(countrySet);
        
        countryList.sort(Country.compareCountry);
        
        System.out.println(countryList.toString());
        
    }
    
    public void deleteCountry(HashSet<Country> countrySet){
        
        Iterator<Country> itSet = countrySet.iterator();
        int counter = 0;
        
        System.out.println("Ingrese el país que desea eliminar: ");
        String deleteCountry = leer.next();
        
        while (itSet.hasNext()) {

            if ( itSet.next().getCountryName().equalsIgnoreCase( deleteCountry) ){
                
                itSet.remove();     
                counter++;
                
            }  
        }
        
        if (counter == 0 ){
            
            System.out.println("El país ingresado no está en la lista o no existe.");
            
        }
        
    } 
}
